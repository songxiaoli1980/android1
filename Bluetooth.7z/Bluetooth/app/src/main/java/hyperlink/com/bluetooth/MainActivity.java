package hyperlink.com.bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    Button bOn,bOff,BList,BVisible;

    ListView listView;
    private BluetoothAdapter BA;
    private Set<BluetoothDevice>pairedDevices;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bOn = (Button) findViewById(R.id.btnon);
        bOff = (Button) findViewById(R.id.btnoff);
        BList = (Button) findViewById(R.id.btnlist);
        BVisible = (Button) findViewById(R.id.btnVisible);

        BA = BluetoothAdapter.getDefaultAdapter();
        listView = (ListView) findViewById(R.id.listView);


    }


    public  void turnon(View view){

        if (!BA.isEnabled()){
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent,0);

        }

    }

    public  void turnoff(View view){

        BA.disable();


    }

    public  void list(View view){

        pairedDevices = BA.getBondedDevices();
        ArrayList list = new ArrayList();

        for(BluetoothDevice bt:pairedDevices)list.add(bt.getName());

        final ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,list);
        listView.setAdapter(adapter);

    }

    public  void visible(View view){

        Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        startActivityForResult(intent,0);

    }

}
