package hyperlink.com.sqlitedemo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by admin on 01-12-2015.
 */
public class DBHelper  extends SQLiteOpenHelper{

    public static final String DATABASE_NAME= "MyDBName.db";
    public static final String CONTACTS_TABLE_NAME= "contacts";
    public static final String CONTACTS_COLOUMN_ID= "id";
    public static final String CONTACTS_COLOUMN_NAME= "name";
    public static final String CONTACTS_COLOUMN_PHONE= "phone";
    public static final String CONTACTS_COLOUMN_STREET= "street";
    public static final String CONTACTS_COLOUMN_COUNTRY= "country";
    public static final String CONTACTS_COLOUMN_EMAIL= "email";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table contacts" +
                "(id integer primary key,name text,phone text,street text,country text,email text)");

    }

    public boolean insertContacts(String name,String phone, String street,String country,String email){
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name",name);
        contentValues.put("phone",phone);
        contentValues.put("street",street);
        contentValues.put("country",country);
        contentValues.put("email", email);

        db.insert("contacts", null, contentValues);
        return true;
    }


    public Cursor getData(int id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from contacts where id ="+id+"",null);
        return res;

    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numberOfRows = (int) DatabaseUtils.queryNumEntries(db,CONTACTS_TABLE_NAME);
        return numberOfRows;
    }

    public boolean updateContacts(Integer id,String name,String phone, String street,String country,String email){
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name",name);
        contentValues.put("phone",phone);
        contentValues.put("street",street);
        contentValues.put("country",country);
        contentValues.put("email", email);
        db.update("contacts",contentValues,"id=?",new String[]{Integer.toString(id)});

        return true;
    }

    public Integer delete(Integer id){
        SQLiteDatabase db = this.getReadableDatabase();
        return db.delete("contacts","id=?",new String[]{Integer.toString(id)});
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS contacts");
        onCreate(db);

    }


    public ArrayList<String> getAllContacts() {
        ArrayList<String> arrayList = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor rs = db.rawQuery("select * from contacts",null);
        rs.moveToFirst();

        while (rs.isAfterLast()==false){
            arrayList.add(rs.getString(rs.getColumnIndex(CONTACTS_COLOUMN_NAME)));
            rs.moveToNext();
        }


            return arrayList;
    }
}
