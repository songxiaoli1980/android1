package hyperlink.com.sqlitedemo;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Display_Contacts extends AppCompatActivity {

    private DBHelper dbHelper;

    TextView name;
    TextView phone;
    TextView street;
    TextView country;
    TextView email;

    int id_To_Update = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display__contacts);

        name = (TextView) findViewById(R.id.editTextname);
        phone = (TextView) findViewById(R.id.editTextphone);
        street = (TextView) findViewById(R.id.editTextstreet);
        country = (TextView) findViewById(R.id.editTextcountry);
        email = (TextView) findViewById(R.id.editTextemail);

        dbHelper = new DBHelper(this);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            int Values = extras.getInt("id");

            if (Values > 0) {
                Cursor rs = dbHelper.getData(Values);
                id_To_Update = Values;
                rs.moveToFirst();

                String nam = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLOUMN_NAME));
                String ph = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLOUMN_PHONE));

                String str = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLOUMN_STREET));

                String cou = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLOUMN_COUNTRY));

                String ema = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLOUMN_EMAIL));

                if(!rs.isClosed()){
                    rs.close();
                }
                Button btn  = (Button) findViewById(R.id.btnsave);
                btn.setVisibility(View.INVISIBLE);

                name.setText((CharSequence)nam);
                name.setFocusable(false);
                name.setClickable(false);

                phone.setText((CharSequence)ph);
                phone.setFocusable(false);
                phone.setClickable(false);

                street.setText((CharSequence)str);
                street.setFocusable(false);
                street.setClickable(false);

                country.setText((CharSequence)cou);
                country.setFocusable(false);
                country.setClickable(false);

                email.setText((CharSequence)ema);
                email.setFocusable(false);
                email.setClickable(false);


            }
        }

    }

    public void save(View view){
        Bundle extras = getIntent().getExtras();
        if (extras!=null){
            int Value = extras.getInt("id");

            if (Value>0){
                if (dbHelper.updateContacts(id_To_Update,name.getText().toString()
                ,phone.getText().toString(),street.getText().toString(),country.getText().toString()
                ,email.getText().toString())){
                    Toast.makeText(getApplicationContext(),"updated sucessfully",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(),"not Updated",Toast.LENGTH_LONG).show();

                }
              }else {
                if (dbHelper.insertContacts(name.getText().toString()
                        ,phone.getText().toString(),street.getText().toString(),country.getText().toString()
                        ,email.getText().toString())){
                    Toast.makeText(getApplicationContext(),"Inserted",Toast.LENGTH_LONG).show();

                }else {
                    Toast.makeText(getApplicationContext(),"not Inserted",Toast.LENGTH_LONG).show();

                }
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        }
    }

}
