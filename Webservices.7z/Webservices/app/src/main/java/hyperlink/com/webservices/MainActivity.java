package hyperlink.com.webservices;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button GetServerData = (Button) findViewById(R.id.btnwebservices);
        GetServerData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //webservice
String serverURL = "http://androidexample.com/media/webservice/JsonReturn.php";
                //use Asynctask
                new Operation().execute(serverURL);
            }
        });

    }


    private class Operation extends AsyncTask<String, Void, Void> {


        //private  final HttpClient Client = new DefaultHttpClient();

        private String Content;
        private String Error = null;
        private ProgressDialog Dialog = new ProgressDialog(MainActivity.this);
        String data = "";
        TextView uiParsed = (TextView) findViewById(R.id.output);
        TextView jsonparsed = (TextView) findViewById(R.id.textViewparsed);

        int sizeData=0;
        EditText serverData = (EditText) findViewById(R.id.editText);

        @Override
        protected void onPreExecute() {
            Dialog.setMessage("Please Wait");
            Dialog.show();
            try{
                data+="&"+ URLEncoder.encode("data","UTF-8")+"="+serverData.getText();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected Void doInBackground(String... urls) {

            //post call
            BufferedReader reader = null;

            //posting data


            try {

                //posting
                URL url = null;
                url = new URL(urls[0]);

                URLConnection connection = url.openConnection();
                connection.setDoOutput(true);

                OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream());
                writer.write(data);
                writer.flush();

                //get Server response
                reader  = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line =null;
                //read response
                while ((line=reader.readLine())!=null){
                    sb.append(line+"\n");
                }
                Content = sb.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }finally {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            Dialog.dismiss();

            if (Error!=null){
                uiParsed.setText("OUTPUT:"+Error);
            }else {
                String OutputData = "";
                JSONObject jsonObjectResponse;

                try{
                    //create jsonObject
                    jsonObjectResponse = new JSONObject(Content);
                    //return value
                    JSONArray jsonArray = jsonObjectResponse.optJSONArray("Android");
                    //parse each object
                    int lengthJsonArr  = jsonArray.length();

                    for (int i=0;i<lengthJsonArr;i++){
                        JSONObject jsonChildNode = jsonArray.getJSONObject(i);

                        //fetch all values
                        String name  = jsonChildNode.optString("name").toString();
                        String number = jsonChildNode.optString("number").toString();
                        String date_added = jsonChildNode.optString("date_added").toString();

                        OutputData += "Name:"+name+"\n"
                                +"Number:"+number+"\n"
                                +"Time:"+date_added+"\n"
                                +"------\n";
                    }
                    jsonparsed.setText(OutputData);


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
