package hyperlink.com.notification;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ((SeekBar)findViewById(R.id.seekBar)).setOnSeekBarChangeListener(this);
    }

    public  void createNotification(View view){

        Intent intent = new Intent(this,NotificationActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,0,intent,0);
        //Build notification
        Notification notification = new Notification.Builder(this)
                .setContentTitle("new mail from"+"XYZ@yahoo.com")
                .setContentText("Subject")
                .setContentIntent(pendingIntent)
                .setSmallIcon(R.drawable.android1)
                .addAction(R.drawable.android1, "Mobile", pendingIntent)
                .addAction(R.drawable.android1,"MAC",pendingIntent)
                .build();

        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notification.flags|= Notification.FLAG_AUTO_CANCEL;
        notificationManager.notify(0,notification);


    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        ((TextView)findViewById(R.id.txtnum)).setText("Progress:"+seekBar.getProgress());
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

        ((TextView)findViewById(R.id.txtchan)).setText("Progress");
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

        ((TextView)findViewById(R.id.txtnum)).setText("Progress"+seekBar.getProgress());
    }
}
